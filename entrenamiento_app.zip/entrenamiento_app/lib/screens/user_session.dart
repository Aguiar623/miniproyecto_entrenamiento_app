
class UserSession {
  static int? currentUserId;
}