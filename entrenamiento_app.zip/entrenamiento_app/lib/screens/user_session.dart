
class UserSession {
  static int? currentUserId;
}   // clase para guardar el id del usuario logueado